function tabuada() {
    let numero = prompt("Digite um número para ver sua tabuada:");
    let resultado = "";
    for (let i = 1; i <= 10; i++) {
        resultado += `${numero} x ${i} = ${numero * i}<br>`;
    }
    document.getElementById("saida").innerHTML = resultado;
}