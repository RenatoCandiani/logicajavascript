function converterTemperaturas() {
    let resultado = "";
    
    for (let celsius = 10; celsius <= 100; celsius += 10) {
        let fahrenheit = (9 * celsius / 5) + 32;
        resultado += `${celsius}°C = ${fahrenheit.toFixed(2)}°F<br>`;
    }
    
    document.getElementById("saida").innerHTML = resultado;
}