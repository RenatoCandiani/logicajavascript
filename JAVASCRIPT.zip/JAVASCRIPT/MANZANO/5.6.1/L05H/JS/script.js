function calcularPotencia() {
    let base = prompt("Digite a base:");
    let expoente = prompt("Digite o expoente:");
    let potencia = 1;
    
    for (let i = 0; i < expoente; i++) {
        potencia *= base;
    }
    
    document.getElementById("saida").innerHTML = `${base} elevado a ${expoente} é: ${potencia}`;
}