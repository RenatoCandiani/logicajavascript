function potenciasDe3() {
    let resultado = "";
    let base = 3;
    for (let i = 0; i <= 15; i++) {
        let potencia = 1;
        for (let j = 0; j < i; j++) {
            potencia *= base;
        }
        resultado += `3 elevado a ${i} = ${potencia}<br>`;
    }
    document.getElementById("saida").innerHTML = resultado;
}