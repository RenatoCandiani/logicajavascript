function fibonacci() {
    let n1 = 1, n2 = 1;
    let resultado = `${n1}<br>${n2}<br>`;
    
    for (let i = 3; i <= 15; i++) {
        let proximo = n1 + n2;
        resultado += `${proximo}<br>`;
        n1 = n2;
        n2 = proximo;
    }
    
    document.getElementById("saida").innerHTML = resultado;
}