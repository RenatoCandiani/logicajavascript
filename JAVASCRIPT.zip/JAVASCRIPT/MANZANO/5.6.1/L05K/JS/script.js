function calcularFatorialImpares() {
    let resultado = "";
    
    for (let i = 1; i <= 10; i += 2) {
        let fatorial = 1;
        for (let j = 1; j <= i; j++) {
            fatorial *= j;
        }
        resultado += `Fatorial de ${i} é: ${fatorial}<br>`;
    }
    
    document.getElementById("saida").innerHTML = resultado;
}