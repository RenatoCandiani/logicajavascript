function calcularQuadrados() {
    let resultado = "";
    for (let i = 15; i <= 200; i++) {
        resultado += `O quadrado de ${i} é ${i * i}<br>`;
    }
    document.getElementById("saida").innerHTML = resultado;
}