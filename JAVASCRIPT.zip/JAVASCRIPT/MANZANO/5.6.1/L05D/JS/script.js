function somarPares() {
    let soma = 0;
    for (let i = 2; i <= 500; i += 2) {
        soma += i;
    }
    document.getElementById("saida").innerHTML = `A soma dos números pares entre 1 e 500 é: ${soma}`;
}