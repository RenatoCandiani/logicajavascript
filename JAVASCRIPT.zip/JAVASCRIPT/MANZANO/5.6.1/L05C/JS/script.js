function somarCemNumeros() {
    let soma = 0;
    for (let i = 1; i <= 100; i++) {
        soma += i;
    }
    document.getElementById("saida").innerHTML = `A soma dos 100 primeiros números é: ${soma}`;
}