function divisiveisPor4() {
    let resultado = "";
    for (let i = 1; i < 200; i++) {
        if (i % 4 === 0) {
            resultado += `${i}<br>`;
        }
    }
    document.getElementById("saida").innerHTML = resultado;
}