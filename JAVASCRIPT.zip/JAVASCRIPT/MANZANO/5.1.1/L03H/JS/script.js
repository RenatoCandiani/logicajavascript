function converterTemperaturas() {
    let celsius = 10;
    let resultado = "";

    while (celsius <= 100) {
        const fahrenheit = (9 * celsius + 160) / 5;
        resultado += `${celsius}°C = ${fahrenheit.toFixed(2)}°F<br>`;
        celsius += 10;
    }

    document.getElementById('resultado').innerHTML = resultado;
}