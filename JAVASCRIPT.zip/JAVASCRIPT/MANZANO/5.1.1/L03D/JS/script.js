function mostrarImpares() {
    let i = 0;
    let resultado = "";

    while (i <= 20) {
        if (i % 2 !== 0) {
            resultado += `${i} `;
        }
        i++;
    }

    document.getElementById('resultado').innerText = `Números ímpares de 0 a 20: ${resultado}`;
}