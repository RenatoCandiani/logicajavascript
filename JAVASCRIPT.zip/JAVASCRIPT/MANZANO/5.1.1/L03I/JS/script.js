function lerValores() {
    let i = 0;
    let soma = 0;
    const totalValores = 10;

    while (i < totalValores) {
        const valor = parseFloat(prompt(`Digite o ${i + 1}º valor:`));
        soma += valor;
        i++;
    }

    const media = soma / totalValores;
    document.getElementById('resultado').innerText = `Soma: ${soma}, Média: ${media}`;
}