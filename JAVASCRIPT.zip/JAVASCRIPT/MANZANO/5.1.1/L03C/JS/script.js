function calcularPares() {
    let i = 1;
    let soma = 0;

    while (i <= 500) {
        if (i % 2 === 0) {
            soma += i;
        }
        i++;
    }

    document.getElementById('resultado').innerText = `A soma dos valores pares entre 1 e 500 é ${soma}.`;
}