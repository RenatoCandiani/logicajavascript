function mostrarFibonacci() {
    let n1 = 1, n2 = 1, i = 2;
    let resultado = "1, 1";

    while (i < 15) {
        let n3 = n1 + n2;
        resultado += `, ${n3}`;
        n1 = n2;
        n2 = n3;
        i++;
    }

    document.getElementById('resultado').innerText = `Série de Fibonacci: ${resultado}`;
}