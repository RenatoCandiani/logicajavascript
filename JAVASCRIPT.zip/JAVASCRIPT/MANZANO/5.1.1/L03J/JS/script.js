function calcularPares() {
    let i = 50;
    let soma = 0;
    let cont = 0;

    while (i <= 70) {
        if (i % 2 === 0) {
            soma += i;
            cont++;
        }
        i++;
    }

    const media = cont > 0 ? soma / cont : 0;
    document.getElementById('resultado').innerText = `Soma: ${soma}, Média: ${media}`;
}