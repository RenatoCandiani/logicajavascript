function mostrarPotencias() {
    let i = 0;
    let resultado = "";

    while (i <= 15) {
        let potencia = 1;
        let j = 0;

        while (j < i) {
            potencia *= 3;
            j++;
        }

        resultado += `3^${i} = ${potencia}<br>`;
        i++;
    }

    document.getElementById('resultado').innerHTML = resultado;
}