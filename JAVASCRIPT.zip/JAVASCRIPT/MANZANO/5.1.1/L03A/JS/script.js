function calcularTabuada() {
    const numero = parseInt(document.getElementById('numero').value);
    let i = 1;
    let resultado = "";

    while (i <= 10) {
        resultado += `${numero} x ${i} = ${numero * i}<br>`;
        i++;
    }

    document.getElementById('resultado').innerHTML = resultado;
}