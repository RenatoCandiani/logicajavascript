function calcularPotencia() {
    const base = parseInt(document.getElementById('base').value);
    const expoente = parseInt(document.getElementById('expoente').value);
    let resultado = 1;
    let i = 0;

    while (i < expoente) {
        resultado *= base;
        i++;
    }

    document.getElementById('resultado').innerText = `${base}^${expoente} = ${resultado}`;
}