function lerValores() {
    let maior = Number.NEGATIVE_INFINITY;
    let menor = Number.POSITIVE_INFINITY;

    while (true) {
        const valor = parseInt(prompt("Digite um valor positivo inteiro (ou um valor negativo para parar):"));
        if (valor < 0) break;

        if (valor > maior) maior = valor;
        if (valor < menor) menor = valor;
    }

    document.getElementById('resultado').innerText = `Maior valor: ${maior}, Menor valor: ${menor}`;
}