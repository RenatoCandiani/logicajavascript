function calcularSoma() {
    let i = 1;
    let soma = 0;

    while (i <= 100) {
        soma += i;
        i++;
    }

    document.getElementById('resultado').innerText = `A soma dos cem primeiros números é ${soma}.`;
}