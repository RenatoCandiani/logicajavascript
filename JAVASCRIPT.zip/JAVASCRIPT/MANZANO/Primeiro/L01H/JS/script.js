function calcularVolumeCaixa() {
    const comprimento = parseFloat(document.getElementById('comprimento').value);
    const largura = parseFloat(document.getElementById('largura').value);
    const altura = parseFloat(document.getElementById('altura').value);
    const volume = comprimento * largura * altura;
    document.getElementById('resultadoH').textContent = `O volume da caixa é: ${volume.toFixed(2)} cm³`;
}