function calcularDistributiva() {
    const a = parseInt(document.getElementById('valorA').value);
    const b = parseInt(document.getElementById('valorB').value);
    const c = parseInt(document.getElementById('valorC').value);
    const d = parseInt(document.getElementById('valorD').value);

    const soma1 = a + b, soma2 = a + c, soma3 = a + d;
    const soma4 = b + c, soma5 = b + d, soma6 = c + d;

    const mult1 = a * b, mult2 = a * c, mult3 = a * d;
    const mult4 = b * c, mult5 = b * d, mult6 = c * d;

    document.getElementById('resultadoG').innerHTML = `
        Somas: ${soma1}, ${soma2}, ${soma3}, ${soma4}, ${soma5}, ${soma6} <br>
        Multiplicações: ${mult1}, ${mult2}, ${mult3}, ${mult4}, ${mult5}, ${mult6}`;
}