function converterFahrenheitParaCelsius() {
    const fahrenheit = parseFloat(document.getElementById('fahrenheit').value);
    const celsius = (fahrenheit - 32) * (5 / 9);
    document.getElementById('resultadoB').textContent = `A temperatura em Celsius é: ${celsius.toFixed(2)}°C`;
}