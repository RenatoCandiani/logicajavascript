function converterRealParaDolar() {
    const real = parseFloat(document.getElementById('real').value);
    const cotacao = parseFloat(document.getElementById('cotacao').value);
    const valorDolar = real / cotacao;
    document.getElementById('resultadoK').textContent = `O valor em dólares é: $${valorDolar.toFixed(2)}`;
}