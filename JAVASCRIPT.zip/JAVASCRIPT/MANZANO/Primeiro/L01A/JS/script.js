function converterCelsiusParaFahrenheit() {
    const celsius = parseFloat(document.getElementById('celsius').value);
    const fahrenheit = (9 * celsius + 160) / 5;
    document.getElementById('resultadoA').textContent = `A temperatura em Fahrenheit é: ${fahrenheit.toFixed(2)}°F`;
}