function calcularQuadradoDaDiferenca() {
    const a = parseInt(document.getElementById('valorA').value);
    const b = parseInt(document.getElementById('valorB').value);
    const resultado = Math.pow(a - b, 2);
    document.getElementById('resultadoI').textContent = `O quadrado da diferença é: ${resultado}`;
}