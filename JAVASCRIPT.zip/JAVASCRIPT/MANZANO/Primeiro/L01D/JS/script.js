function calcularCombustivel() {
    const tempo = parseFloat(document.getElementById('tempo').value);
    const velocidade = parseFloat(document.getElementById('velocidade').value);
    const distancia = tempo * velocidade;
    const litrosUsados = distancia / 12;
    document.getElementById('resultadoD').textContent = `Velocidade média: ${velocidade} km/h, Tempo: ${tempo} horas, Distância: ${distancia} km, Litros utilizados: ${litrosUsados.toFixed(2)} litros`;
}