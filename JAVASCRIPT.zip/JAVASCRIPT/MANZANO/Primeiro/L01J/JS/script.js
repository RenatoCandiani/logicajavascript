function converterDolarParaReal() {
    const dolar = parseFloat(document.getElementById('dolar').value);
    const cotacao = parseFloat(document.getElementById('cotacao').value);
    const valorReal = dolar * cotacao;
    document.getElementById('resultadoJ').textContent = `O valor em reais é: R$ ${valorReal.toFixed(2)}`;
}