function calcularSomaDosQuadrados() {
    const a = parseFloat(document.getElementById('valorA').value);
    const b = parseFloat(document.getElementById('valorB').value);
    const c = parseFloat(document.getElementById('valorC').value);
    const somaQuadrados = Math.pow(a, 2) + Math.pow(b, 2) + Math.pow(c, 2);
    document.getElementById('resultadoL').textContent = `A soma dos quadrados é: ${somaQuadrados}`;
}