function calcularPrestacao() {
    const valor = parseFloat(document.getElementById('valor').value);
    const taxa = parseFloat(document.getElementById('taxa').value);
    const tempo = parseFloat(document.getElementById('tempo').value);
    const prestacao = valor + (valor * (taxa / 100)) * tempo;
    document.getElementById('resultadoE').textContent = `O valor da prestação em atraso é: R$ ${prestacao.toFixed(2)}`;
}