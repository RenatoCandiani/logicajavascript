function trocarValores() {
    let a = document.getElementById('valorA').value;
    let b = document.getElementById('valorB').value;
    [a, b] = [b, a];
    document.getElementById('resultadoF').textContent = `Após a troca, A = ${a} e B = ${b}`;
}