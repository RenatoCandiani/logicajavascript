function calcularVolumeLata() {
    const raio = parseFloat(document.getElementById('raio').value);
    const altura = parseFloat(document.getElementById('altura').value);
    const volume = Math.PI * Math.pow(raio, 2) * altura;
    document.getElementById('resultadoC').textContent = `O volume da lata de óleo é: ${volume.toFixed(2)} cm³`;
}