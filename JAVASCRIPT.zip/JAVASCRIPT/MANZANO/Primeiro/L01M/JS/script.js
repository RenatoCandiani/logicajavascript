function calcularQuadradoDaSoma() {
    const a = parseFloat(document.getElementById('valorA').value);
    const b = parseFloat(document.getElementById('valorB').value);
    const c = parseFloat(document.getElementById('valorC').value);
    const soma = a + b + c;
    const quadradoSoma = Math.pow(soma, 2);
    document.getElementById('resultadoM').textContent = `O quadrado da soma é: ${quadradoSoma}`;
}