function calcularNovoSalario() {
    const SM = parseFloat(document.getElementById('salario').value);
    const PR = parseFloat(document.getElementById('percentual').value);

    const NS = SM + (SM * PR / 100);

    document.getElementById('resultadoSalario').textContent = `Novo salário: R$ ${NS.toFixed(2)}`;
}