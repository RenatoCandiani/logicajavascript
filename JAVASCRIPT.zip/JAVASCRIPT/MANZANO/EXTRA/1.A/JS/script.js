function calcularProdutoESoma() {
    const A = parseFloat(document.getElementById('valorA').value);
    const B = parseFloat(document.getElementById('valorB').value);
    const C = parseFloat(document.getElementById('valorC').value);
    const D = parseFloat(document.getElementById('valorD').value);

    const P = A * C;
    const S = B + D;

    document.getElementById('resultadoP').textContent = `Produto de A e C: ${P}`;
    document.getElementById('resultadoS').textContent = `Soma de B e D: ${S}`;
}