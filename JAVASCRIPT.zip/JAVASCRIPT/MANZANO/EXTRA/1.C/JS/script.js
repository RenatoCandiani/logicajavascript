function calcularVotos() {
    const votosA = parseFloat(document.getElementById('votosA').value);
    const votosB = parseFloat(document.getElementById('votosB').value);
    const votosC = parseFloat(document.getElementById('votosC').value);
    const votosNulos = parseFloat(document.getElementById('votosNulos').value);
    const votosBrancos = parseFloat(document.getElementById('votosBrancos').value);

    const totalEleitores = votosA + votosB + votosC + votosNulos + votosBrancos;
    const percentualValidos = ((votosA + votosB + votosC) / totalEleitores) * 100;
    const percentualA = (votosA / totalEleitores) * 100;
    const percentualB = (votosB / totalEleitores) * 100;
    const percentualC = (votosC / totalEleitores) * 100;
    const percentualNulos = (votosNulos / totalEleitores) * 100;
    const percentualBrancos = (votosBrancos / totalEleitores) * 100;

    document.getElementById('resultadoTotal').textContent = `Total de eleitores: ${totalEleitores}`;
    document.getElementById('percentualValidos').textContent = `Percentual de votos válidos: ${percentualValidos.toFixed(2)}%`;
    document.getElementById('percentualA').textContent = `Percentual de votos do candidato A: ${percentualA.toFixed(2)}%`;
    document.getElementById('percentualB').textContent = `Percentual de votos do candidato B: ${percentualB.toFixed(2)}%`;
    document.getElementById('percentualC').textContent = `Percentual de votos do candidato C: ${percentualC.toFixed(2)}%`;
    document.getElementById('percentualNulos').textContent = `Percentual de votos nulos: ${percentualNulos.toFixed(2)}%`;
    document.getElementById('percentualBrancos').textContent = `Percentual de votos em branco: ${percentualBrancos.toFixed(2)}%`;
}