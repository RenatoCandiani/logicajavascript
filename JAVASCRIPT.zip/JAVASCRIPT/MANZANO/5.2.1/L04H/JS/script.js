function calcularAreaResidencia() {
    let totalArea = 0;
    let continuar = true;

    do {
        const nome = prompt("Digite o nome do cômodo:");
        const largura = parseFloat(prompt("Digite a largura do cômodo:"));
        const comprimento = parseFloat(prompt("Digite o comprimento do cômodo:"));
        const area = largura * comprimento;
        totalArea += area;

        continuar = confirm("Deseja adicionar outro cômodo? (OK para sim, Cancelar para não)");
    } while (continuar);

    document.getElementById('resultado').innerText = `Área total da residência: ${totalArea} m²`;
}