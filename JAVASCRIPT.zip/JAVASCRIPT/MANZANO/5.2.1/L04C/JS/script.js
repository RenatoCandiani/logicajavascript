function calcularDivisiveisPor4() {
    let i = 1;
    let resultado = '';

    do {
        if (i % 4 === 0) {
            resultado += `${i}<br>`;
        }
        i++;
    } while (i < 200);

    document.getElementById('resultado').innerHTML = resultado;
}