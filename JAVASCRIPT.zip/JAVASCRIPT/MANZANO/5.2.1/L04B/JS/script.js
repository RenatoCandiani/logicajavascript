function calcularSomatorioPares() {
    let i = 1;
    let somatorio = 0;

    do {
        if (i % 2 === 0) {
            somatorio += i;
        }
        i++;
    } while (i <= 500);

    document.getElementById('resultado').innerText = `Somatório: ${somatorio}`;
}