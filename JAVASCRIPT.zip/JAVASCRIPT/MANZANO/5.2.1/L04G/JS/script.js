function calcularFatorialImpares() {
    let i = 1;
    let resultado = '';

    do {
        if (i % 2 !== 0) {
            let fatorial = 1;
            for (let j = 1; j <= i; j++) {
                fatorial *= j;
            }
            resultado += `Fatorial de ${i}: ${fatorial}<br>`;
        }
        i++;
    } while (i <= 10);

    document.getElementById('resultado').innerHTML = resultado;
}