function calcularGraosTrigo() {
    let i = 1;
    let somatorio = 0;
    let graos = 1

    do {
        somatorio += graos;
        graos *= 2;
        i++;
    } while (i <= 64);

    document.getElementById('resultado').innerText = `Somatório de grãos: ${somatorio}`;
}