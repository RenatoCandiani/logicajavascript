function calcularFatorial() {
    let i = 0;
    let somatorio = 0;

    do {
        const valor = parseInt(prompt(`Digite o ${i + 1}º valor:`));
        let fatorial = 1;

        for (let j = 1; j <= valor; j++) {
            fatorial *= j;
        }

        somatorio += fatorial;
        i++;
    } while (i < 15);

    document.getElementById('resultado').innerText = `Somatório das fatoriais: ${somatorio}`;
}