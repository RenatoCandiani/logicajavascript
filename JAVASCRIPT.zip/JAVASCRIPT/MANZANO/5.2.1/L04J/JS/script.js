function dividirNumeros() {
    const dividendo = parseInt(prompt("Digite o dividendo:"));
    const divisor = parseInt(prompt("Digite o divisor:"));
    let quociente = 0;

    if (divisor === 0) {
        document.getElementById('resultado').innerText = "Divisão por zero não é permitida.";
        return;
    }

    while (dividendo >= divisor) {
        dividendo -= divisor;
        quociente++;
    }

    document.getElementById('resultado').innerText = `Quociente: ${quociente}, Resto: ${dividendo}`;
}