function lerValores() {
    let soma = 0;
    let cont = 0;
    let valor;

    do {
        valor = parseFloat(prompt("Digite um valor positivo (ou um valor negativo para parar):"));
        if (valor >= 0) {
            soma += valor;
            cont++;
        }
    } while (valor >= 0);

    const media = cont > 0 ? soma / cont : 0;
    document.getElementById('resultado').innerText = `Somatório: ${soma}, Média: ${media}, Total de valores: ${cont}`;
}