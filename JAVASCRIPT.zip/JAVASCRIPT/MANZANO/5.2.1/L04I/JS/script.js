function lerValores() {
    let maior = Number.NEGATIVE_INFINITY;
    let menor = Number.POSITIVE_INFINITY;
    let valor;

    do {
        valor = parseInt(prompt("Digite um valor positivo inteiro (ou um valor negativo para parar):"));
        if (valor >= 0) {
            if (valor > maior) maior = valor;
            if (valor < menor) menor = valor;
        }
    } while (valor >= 0);

    document.getElementById('resultado').innerText = `Maior valor: ${maior}, Menor valor: ${menor}`;
}