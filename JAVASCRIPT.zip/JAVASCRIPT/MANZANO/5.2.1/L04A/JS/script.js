function calcularQuadrados() {
    let i = 15;
    let resultado = '';

    do {
        resultado += `Quadrado de ${i}: ${i * i}<br>`;
        i++;
    } while (i <= 200);

    document.getElementById('resultado').innerHTML = resultado;
}