function converterTemperatura() {
    const fahrenheit = parseFloat(document.getElementById('fahrenheit').value);
    const celsius = (fahrenheit - 32) * 5 / 9;
    document.getElementById('resultado').textContent = `${fahrenheit}°F equivalem a ${celsius.toFixed(2)}°C`;
}