function calcularCombustivel() {
    const litros = parseFloat(document.getElementById('litros').value);
    const tipo = document.getElementById('tipo').value.toUpperCase();

    let precoLitro;
    let desconto;

    if (tipo === 'A') {
        precoLitro = 2.90;
        desconto = litros <= 20 ? 0.03 : 0.05;
    } else if (tipo === 'G') {
        precoLitro = 3.30;
        desconto = litros <= 20 ? 0.04 : 0.06;
    } else {
        document.getElementById('resultado').textContent = 'Tipo de combustível inválido.';
        return;
    }

    const valorSemDesconto = litros * precoLitro;
    const valorDesconto = valorSemDesconto * desconto;
    const valorFinal = valorSemDesconto - valorDesconto;

    document.getElementById('resultado').textContent = `Valor a pagar: R$ ${valorFinal.toFixed(2)}`;
}