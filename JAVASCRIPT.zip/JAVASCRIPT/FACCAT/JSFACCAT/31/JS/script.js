function verificarTriangulo() {
    const ladoA = parseFloat(document.getElementById('ladoA').value);
    const ladoB = parseFloat(document.getElementById('ladoB').value);
    const ladoC = parseFloat(document.getElementById('ladoC').value);

    if (ladoA < (ladoB + ladoC) && ladoB < (ladoA + ladoC) && ladoC < (ladoA + ladoB)) {
        document.getElementById('resultado').textContent = 'Os valores formam um triângulo';
    } else {
        document.getElementById('resultado').textContent = 'Os valores NÃO formam um triângulo';
    }
}