function verificarValor() {
    const valor = parseFloat(document.getElementById('valor').value);
    
    if (valor === 10) {
        document.getElementById('resultado').textContent = 'Esse número é o 10!';
    } else if (valor > 10) {
        document.getElementById('resultado').textContent = 'É MAIOR QUE 10!';
    } else {
        document.getElementById('resultado').textContent = 'NÃO É MAIOR QUE 10!';
    }
}