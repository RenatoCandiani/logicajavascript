function calcularSalario() {
    const horasTrabalhadas = parseFloat(document.getElementById('horasTrabalhadas').value);
    const salarioHora = parseFloat(document.getElementById('salarioHora').value);
    const horasNormais = 160; // 40 horas por semana * 4 semanas
    let salarioTotal;

    if (horasTrabalhadas > horasNormais) {
        const horasExtras = horasTrabalhadas - horasNormais;
        const salarioExtras = horasExtras * salarioHora * 1.5;
        salarioTotal = horasNormais * salarioHora + salarioExtras;
    } else {
        salarioTotal = horasTrabalhadas * salarioHora;
    }

    document.getElementById('resultado').textContent = `O salário total é R$ ${salarioTotal.toFixed(2)}`;
}