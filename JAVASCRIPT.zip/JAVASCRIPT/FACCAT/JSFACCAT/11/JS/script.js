function calcularSalario() {
    const carrosVendidos = parseInt(document.getElementById('carrosVendidos').value);
    const totalVendas = parseFloat(document.getElementById('totalVendas').value);
    const salarioFixo = parseFloat(document.getElementById('salarioFixo').value);
    const comissaoCarro = parseFloat(document.getElementById('comissaoCarro').value);

    const comissaoVendas = totalVendas * 0.05;
    const salarioFinal = salarioFixo + (carrosVendidos * comissaoCarro) + comissaoVendas;
    document.getElementById('resultado').textContent = `O salário final é R$ ${salarioFinal.toFixed(2)}`;
}