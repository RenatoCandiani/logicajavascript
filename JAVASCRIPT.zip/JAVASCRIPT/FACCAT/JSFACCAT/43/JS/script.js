function verificarTriangulo() {
    const a = parseFloat(prompt("Informe o valor do lado A:"));
    const b = parseFloat(prompt("Informe o valor do lado B:"));
    const c = parseFloat(prompt("Informe o valor do lado C:"));

    if (a < b + c && b < a + c && c < a + b) {
        if (a === b && b === c) {
            console.log("Triângulo Equilátero");
        } else if (a === b || b === c || a === c) {
            console.log("Triângulo Isósceles");
        } else {
            console.log("Triângulo Escaleno");
        }
    } else {
        console.log("Não é possível formar um triângulo");
    }
}