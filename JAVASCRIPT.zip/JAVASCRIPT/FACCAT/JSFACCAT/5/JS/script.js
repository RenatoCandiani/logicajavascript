function mostrarAntecessor() {
    const number = parseInt(document.getElementById('numberInputAntecessor').value);
    const antecessor = number - 1;
    document.getElementById('resultadoAntecessor').textContent = `O antecessor de ${number} é ${antecessor}`;
}

function mostrarSucessor() {
    const number = parseInt(document.getElementById('numberInputSucessor').value);
    const sucessor = number + 1;
    document.getElementById('resultadoSucessor').textContent = `O sucessor de ${number} é ${sucessor}`;
}