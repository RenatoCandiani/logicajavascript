function compararValores() {
    const valor1 = parseFloat(document.getElementById('valor1').value);
    const valor2 = parseFloat(document.getElementById('valor2').value);

    let resultado;
    if (valor1 === valor2) {
        resultado = 'Números iguais';
    } else if (valor1 > valor2) {
        resultado = 'Primeiro é maior';
    } else {
        resultado = 'Segundo é maior';
    }

    document.getElementById('resultado').textContent = resultado;
}