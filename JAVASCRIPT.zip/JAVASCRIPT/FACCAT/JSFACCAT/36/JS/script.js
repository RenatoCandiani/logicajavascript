function calcularIdades() {
    const homem1 = parseInt(prompt("Informe a idade do primeiro homem:"));
    const homem2 = parseInt(prompt("Informe a idade do segundo homem:"));
    const mulher1 = parseInt(prompt("Informe a idade da primeira mulher:"));
    const mulher2 = parseInt(prompt("Informe a idade da segunda mulher:"));

    const homemMaisVelho = Math.max(homem1, homem2);
    const homemMaisNovo = Math.min(homem1, homem2);
    const mulherMaisNova = Math.min(mulher1, mulher2);
    const mulherMaisVelha = Math.max(mulher1, mulher2);

    const soma = homemMaisVelho + mulherMaisNova;
    const produto = homemMaisNovo * mulherMaisVelha;

    console.log(`Soma das idades: ${soma}`);
    console.log(`Produto das idades: ${produto}`);
}