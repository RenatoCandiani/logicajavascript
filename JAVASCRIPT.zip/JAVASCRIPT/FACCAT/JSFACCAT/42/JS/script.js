function verificarAposentadoria() {
    const codigo = prompt("Informe o código do empregado:");
    const anoNascimento = parseInt(prompt("Informe o ano de nascimento:"));
    const anoIngresso = parseInt(prompt("Informe o ano de ingresso na empresa:"));

    const anoAtual = new Date().getFullYear();
    const idade = anoAtual - anoNascimento;
    const tempoTrabalho = anoAtual - anoIngresso;

    if (idade >= 65 || tempoTrabalho >= 30 || (idade >= 60 && tempoTrabalho >= 25)) {
        console.log(`Empregado ${codigo} pode requerer aposentadoria.`);
    } else {
        console.log(`Empregado ${codigo} não pode requerer aposentadoria.`);
    }

    console.log(`Idade: ${idade}`);
    console.log(`Tempo de trabalho: ${tempoTrabalho}`);
}