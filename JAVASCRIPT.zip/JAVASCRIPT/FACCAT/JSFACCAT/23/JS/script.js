function calcularPesoIdeal() {
    const altura = parseFloat(document.getElementById('altura').value);
    const sexo = document.getElementById('sexo').value.toUpperCase();
    let pesoIdeal;

    if (sexo === "M") {
        pesoIdeal = (72.7 * altura) - 58;
    } else if (sexo === "F") {
        pesoIdeal = (62.1 * altura) - 44.7;
    } else {
        document.getElementById('resultado').textContent = "Sexo inválido. Use M ou F.";
        return;
    }

    document.getElementById('resultado').textContent = `O peso ideal é ${pesoIdeal.toFixed(2)} kg.`;
}
