function ordenarValores() {
    const valores = [
        parseFloat(document.getElementById('valor1').value),
        parseFloat(document.getElementById('valor2').value),
        parseFloat(document.getElementById('valor3').value)
    ];

    valores.sort((a, b) => a - b); // Ordena em ordem crescente

    document.getElementById('resultado').textContent = `Valores em ordem crescente: ${valores.join(', ')}`;
}