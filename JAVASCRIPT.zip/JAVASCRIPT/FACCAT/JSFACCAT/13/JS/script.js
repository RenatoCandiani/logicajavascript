function calcularMedia() {
    const nota1 = parseFloat(document.getElementById('nota1').value);
    const nota2 = parseFloat(document.getElementById('nota2').value);
    const nota3 = parseFloat(document.getElementById('nota3').value);

    const media = (nota1 * 2 + nota2 * 3 + nota3 * 5) / 10;
    document.getElementById('resultado').textContent = `A média final é ${media.toFixed(2)}`;
}