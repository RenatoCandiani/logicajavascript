function calcularIdade() {
    const anos = parseInt(document.getElementById('anos').value);
    const meses = parseInt(document.getElementById('meses').value);
    const dias = parseInt(document.getElementById('dias').value);
    const idadeEmDias = (anos * 365) + (meses * 30) + dias;
    document.getElementById('resultado').textContent = `Sua idade expressa em dias é ${idadeEmDias}`;
}