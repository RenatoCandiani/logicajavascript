function verificarVencedor() {
    const time1 = document.getElementById('time1').value;
    const gols1 = parseInt(document.getElementById('gols1').value);
    const time2 = document.getElementById('time2').value;
    const gols2 = parseInt(document.getElementById('gols2').value);

    let resultado;
    if (gols1 > gols2) {
        resultado = `O vencedor é o ${time1}`;
    } else if (gols2 > gols1) {
        resultado = `O vencedor é o ${time2}`;
    } else {
        resultado = 'EMPATE';
    }

    document.getElementById('resultado').textContent = resultado;
}