function calcularAreaRetangulo() {
    const largura = parseFloat(document.getElementById('larguraRetangulo').value);
    const altura = parseFloat(document.getElementById('alturaRetangulo').value);
    const area = largura * altura;
    document.getElementById('resultadoRetangulo').textContent = `A área do retângulo é ${area} cm²`;
}

function calcularAreaTriangulo() {
    const base = parseFloat(document.getElementById('baseTriangulo').value);
    const altura = parseFloat(document.getElementById('alturaTriangulo').value);
    const area = (base * altura) / 2;
    document.getElementById('resultadoTriangulo').textContent = `A área do triângulo é ${area} cm²`;
}

function calcularAreaQuadrado() {
    const lado = parseFloat(document.getElementById('ladoQuadrado').value);
    const area = lado * lado;
    document.getElementById('resultadoQuadrado').textContent = `A área do quadrado é ${area} cm²`;
}

function calcularAreaCirculo() {
    const raio = parseFloat(document.getElementById('raioCirculo').value);
    const area = Math.PI * Math.pow(raio, 2);
    document.getElementById('resultadoCirculo').textContent = `A área do círculo é ${area.toFixed(2)} cm²`;
}

function calcularAreaHexagono() {
    const lado = parseFloat(document.getElementById('ladoHexagono').value);
    const area = ((3 * Math.sqrt(3)) / 2) * Math.pow(lado, 2);
    document.getElementById('resultadoHexagono').textContent = `A área do hexágono é ${area.toFixed(2)} cm²`;
}