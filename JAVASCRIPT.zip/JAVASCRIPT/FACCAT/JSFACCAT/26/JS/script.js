function calcularEstoque() {
    const quantAtual = parseFloat(document.getElementById('quantAtual').value);
    const quantMax = parseFloat(document.getElementById('quantMax').value);
    const quantMin = parseFloat(document.getElementById('quantMin').value);

    const quantMedia = (quantMax + quantMin) / 2;
    const mensagem = quantAtual >= quantMedia ? 'Não efetuar compra' : 'Efetuar compra';

    document.getElementById('resultado').textContent = `Quantidade média: ${quantMedia}. ${mensagem}`;
}