function calcularReajuste() {
    const salario = parseFloat(document.getElementById('salario').value);
    const percentual = parseFloat(document.getElementById('percentual').value);
    const novoSalario = salario + (salario * percentual / 100);
    document.getElementById('resultado').textContent = `O novo salário é R$ ${novoSalario.toFixed(2)}`;
}