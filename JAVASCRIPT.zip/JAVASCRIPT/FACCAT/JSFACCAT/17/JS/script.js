function calcularMedia() {
    const nota1 = parseFloat(document.getElementById('nota1').value);
    const nota2 = parseFloat(document.getElementById('nota2').value);
    const media = (nota1 + nota2) / 2;

    let resultado = `A média é ${media.toFixed(2)}. `;
    resultado += media >= 6 ? "Aluno aprovado." : "Aluno reprovado.";

    document.getElementById('resultado').textContent = resultado;
}