function validarLogin() {
    const codigoCorreto = 1234;
    const senhaCorreta = 9999;

    const codigoUsuario = parseInt(prompt("Informe o código de usuário:"));

    if (codigoUsuario !== codigoCorreto) {
        alert("Usuário inválido!");
    } else {
        const senhaUsuario = parseInt(prompt("Informe a senha:"));

        if (senhaUsuario !== senhaCorreta) {
            alert("Senha incorreta!");
        } else {
            alert("Acesso permitido");
        }
    }
}