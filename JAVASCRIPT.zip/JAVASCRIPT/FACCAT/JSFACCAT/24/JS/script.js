function calcularSalarioComissao() {
    const salarioFixo = parseFloat(document.getElementById('salarioFixo').value);
    const vendas = parseFloat(document.getElementById('vendas').value);

    let comissao;
    if (vendas <= 1500) {
        comissao = vendas * 0.03;
    } else {
        comissao = (1500 * 0.03) + ((vendas - 1500) * 0.05);
    }

    const salarioTotal = salarioFixo + comissao;
    document.getElementById('resultado').textContent = `O salário total é R$ ${salarioTotal.toFixed(2)}`;
}