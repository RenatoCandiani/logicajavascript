function verificarPositivoNegativo() {
    const valor = parseFloat(document.getElementById('valor').value);
    if (valor >= 0) {
        document.getElementById('resultado').textContent = 'O valor é positivo.';
    } else {
        document.getElementById('resultado').textContent = 'O valor é negativo.';
    }
}