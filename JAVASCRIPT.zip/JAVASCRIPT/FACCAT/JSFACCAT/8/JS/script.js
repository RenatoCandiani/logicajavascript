function calcularPercentuais() {
    const eleitores = parseInt(document.getElementById('eleitores').value);
    const brancos = parseInt(document.getElementById('brancos').value);
    const nulos = parseInt(document.getElementById('nulos').value);
    const validos = parseInt(document.getElementById('validos').value);

    if (isNaN(eleitores) || isNaN(brancos) || isNaN(nulos) || isNaN(validos) || eleitores === 0) {
        document.getElementById('resultado').innerHTML = 'Por favor, preencha todos os campos corretamente.';
        return;
    }

    const percBrancos = (brancos / eleitores) * 100;
    const percNulos = (nulos / eleitores) * 100;
    const percValidos = (validos / eleitores) * 100;

    document.getElementById('resultado').innerHTML = 
        `Percentual de votos brancos: ${percBrancos.toFixed(2)}%<br>` +
        `Percentual de votos nulos: ${percNulos.toFixed(2)}%<br>` +
        `Percentual de votos válidos: ${percValidos.toFixed(2)}%`;
}