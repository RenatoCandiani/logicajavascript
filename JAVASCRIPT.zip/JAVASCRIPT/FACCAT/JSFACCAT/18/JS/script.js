function verificarVoto() {
    const anoNascimento = parseInt(document.getElementById('anoNascimento').value);
    const anoAtual = parseInt(document.getElementById('anoAtual').value);
    const idade = anoAtual - anoNascimento;

    const podeVotar = idade >= 16 ? "Pode votar." : "Não pode votar.";
    document.getElementById('resultado').textContent = `Idade: ${idade}. ${podeVotar}`;
}