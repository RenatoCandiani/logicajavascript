function calcularValorCompra() {
    const kgMorango = parseFloat(prompt("Informe a quantidade de morangos (kg):"));
    const kgMaca = parseFloat(prompt("Informe a quantidade de maçãs (kg):"));

    let precoMorango = kgMorango <= 5 ? 2.50 : 2.20;
    let precoMaca = kgMaca <= 5 ? 1.80 : 1.50;

    let totalMorango = kgMorango * precoMorango;
    let totalMaca = kgMaca * precoMaca;
    let totalCompra = totalMorango + totalMaca;

    if (kgMorango + kgMaca > 8 || totalCompra > 25) {
        totalCompra *= 0.9;  // Aplicar desconto de 10%
    }

    console.log(`Total a pagar: R$ ${totalCompra.toFixed(2)}`);
}