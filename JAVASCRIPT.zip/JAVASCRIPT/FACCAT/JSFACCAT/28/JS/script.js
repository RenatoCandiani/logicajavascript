function maiorValor() {
    const valor1 = parseFloat(document.getElementById('valor1').value);
    const valor2 = parseFloat(document.getElementById('valor2').value);
    const valor3 = parseFloat(document.getElementById('valor3').value);

    const maior = Math.max(valor1, valor2, valor3);
    document.getElementById('resultado').textContent = `O maior valor é ${maior}`;
}