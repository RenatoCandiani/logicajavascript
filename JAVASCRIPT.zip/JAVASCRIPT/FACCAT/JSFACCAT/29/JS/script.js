function somaMaiores() {
    const valores = [
        parseFloat(document.getElementById('valor1').value),
        parseFloat(document.getElementById('valor2').value),
        parseFloat(document.getElementById('valor3').value)
    ];

    valores.sort((a, b) => b - a); // Ordena em ordem decrescente
    const soma = valores[0] + valores[1];

    document.getElementById('resultado').textContent = `A soma dos dois maiores valores é ${soma}`;
}