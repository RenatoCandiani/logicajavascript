function calcularDuracao() {
    const inicio = parseInt(document.getElementById('inicio').value);
    const fim = parseInt(document.getElementById('fim').value);

    let duracao;
    if (fim >= inicio) {
        duracao = fim - inicio;
    } else {
        duracao = (24 - inicio) + fim;
    }

    document.getElementById('resultado').textContent = `A duração do jogo foi de ${duracao} horas.`;
}