function calcularCustoFinal() {
    const custoFabrica = parseFloat(document.getElementById('custoFabrica').value);
    const percentualDistribuidor = 0.28;
    const percentualImpostos = 0.45;

    const custoFinal = custoFabrica + (custoFabrica * percentualDistribuidor) + (custoFabrica * percentualImpostos);
    document.getElementById('resultado').textContent = `O custo final ao consumidor é R$ ${custoFinal.toFixed(2)}`;
}