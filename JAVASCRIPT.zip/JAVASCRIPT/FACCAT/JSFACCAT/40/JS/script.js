function calcularDesconto() {
    const produto = prompt("Informe o nome do produto:");
    const quantidade = parseInt(prompt("Informe a quantidade adquirida:"));
    const precoUnitario = parseFloat(prompt("Informe o preço unitário do produto:"));

    const total = quantidade * precoUnitario;
    let desconto = 0;

    if (quantidade <= 5) {
        desconto = total * 0.02;
    } else if (quantidade <= 10) {
        desconto = total * 0.03;
    } else {
        desconto = total * 0.05;
    }

    const totalPagar = total - desconto;

    console.log(`Produto: ${produto}`);
    console.log(`Total sem desconto: R$ ${total.toFixed(2)}`);
    console.log(`Desconto: R$ ${desconto.toFixed(2)}`);
    console.log(`Total a pagar: R$ ${totalPagar.toFixed(2)}`);
}