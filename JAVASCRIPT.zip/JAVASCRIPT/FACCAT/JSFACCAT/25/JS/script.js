function calcularSaldo() {
    const saldo = parseFloat(document.getElementById('saldo').value);
    const debito = parseFloat(document.getElementById('debito').value);
    const credito = parseFloat(document.getElementById('credito').value);

    const saldoAtual = saldo - debito + credito;
    const mensagem = saldoAtual >= 0 ? 'Saldo Positivo' : 'Saldo Negativo';

    document.getElementById('resultado').textContent = `Saldo atual: R$ ${saldoAtual.toFixed(2)}. ${mensagem}`;
}