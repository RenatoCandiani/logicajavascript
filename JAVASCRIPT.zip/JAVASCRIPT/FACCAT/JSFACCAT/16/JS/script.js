function calcularCusto() {
    const quantidade = parseInt(document.getElementById('quantidade').value);
    let preco = 1.30;

    if (quantidade >= 12) {
        preco = 1.00;
    }

    const custoTotal = quantidade * preco;
    document.getElementById('resultado').textContent = `O custo total da compra é R$ ${custoTotal.toFixed(2)}`;
}