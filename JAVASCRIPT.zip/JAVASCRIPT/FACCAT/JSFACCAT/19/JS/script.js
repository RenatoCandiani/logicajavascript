function escreverMaior() {
    const valor1 = parseFloat(document.getElementById('valor1').value);
    const valor2 = parseFloat(document.getElementById('valor2').value);

    if (valor1 === valor2) {
        document.getElementById('resultado').textContent = 'Os dois valores são iguais.';
    } else {
        const maior = valor1 > valor2 ? valor1 : valor2;
        document.getElementById('resultado').textContent = `O maior valor é ${maior}`;
    }
}