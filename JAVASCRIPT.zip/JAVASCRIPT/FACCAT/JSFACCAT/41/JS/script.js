function calcularMedia() {
    const N1 = parseFloat(prompt("Informe a nota 1:"));
    const N2 = parseFloat(prompt("Informe a nota 2:"));
    const N3 = parseFloat(prompt("Informe a nota 3:"));
    const mediaExercicios = parseFloat(prompt("Informe a média dos exercícios:"));

    const mediaAproveitamento = (N1 + N2 * 2 + N3 * 3 + mediaExercicios) / 7;
    let conceito;

    if (mediaAproveitamento >= 9) {
        conceito = 'A';
    } else if (mediaAproveitamento >= 7.5) {
        conceito = 'B';
    } else if (mediaAproveitamento >= 6) {
        conceito = 'C';
    } else {
        conceito
        conceito = 'D';
    }

    console.log(`Média de Aproveitamento: ${mediaAproveitamento.toFixed(2)}`);
    console.log(`Conceito: ${conceito}`);
}